﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NVIDIA.PhysX;
namespace Physx.Test
{
    internal class ErrorCallback : PxErrorCallback
    {
        public override void reportError(PxErrorCode code, string message, string file, int line)
        {
            base.reportError(code, message, file, line);
        }
    }
}
