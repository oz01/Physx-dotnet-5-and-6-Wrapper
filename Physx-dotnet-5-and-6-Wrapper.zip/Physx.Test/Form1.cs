using NVIDIA.PhysX;
namespace Physx.Test
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        PxFoundation? foundation = null;
        PxDefaultAllocator defaultAllocator = new PxDefaultAllocator();
        ErrorCallback errorCallback = new ErrorCallback();
        PxPhysics? physics = null;
        PxScene? scene = null;
        PxMaterial? material = null;
        PxSphereGeometry? Sphere = null;
        PxRigidDynamic? rd = null;
        PxRigidStatic? rs1 = null;
        PxRigidStatic? rs2 = null;
        private void Form1_Load(object sender, EventArgs e)
        {

            foundation = PxFoundation.create(PxVersion.PX_PHYSICS_VERSION, defaultAllocator, errorCallback);
            physics = foundation.createPhysics(PxVersion.PX_PHYSICS_VERSION, new PxTolerancesScale());
            PxSceneDesc sceneDesc = new PxSceneDesc(physics.getTolerancesScale());
            sceneDesc.gravity = new PxVec3(0.0f, -10.0f, 0.0f);
            sceneDesc.cpuDispatcher = PxCpuDispatcher.createDefault(2);
            sceneDesc.filterShader = PxDefaultSimulationFilterShader.function;
            scene = physics.createScene(sceneDesc);
            material = physics.createMaterial(0.5f, 0.5f, 0.5f);
            PxPlaneGeometry pxPlaneGeometry = new PxPlaneGeometry();


            var shape = physics.createShape(pxPlaneGeometry, material);
            rs1 = physics.createRigidStatic(PxTransform.identity);

            rs1.attachShape(shape);
            scene.addActor(rs1);
            Sphere = new PxSphereGeometry();
            Sphere.radius = 1.0f;
            var s2 = physics.createShape(Sphere, material);
            rd = physics.createRigidDynamic(new PxTransform(new PxVec3(1.0f ,20.0f,2.0f)));
            rd.attachShape(s2);
            scene.addActor(rd);
             rs2 = physics.createRigidStatic(new PxTransform(new PxVec3(0.0f, -10.0f, 0.0f)));
            rs2.attachShape(physics.createShape(new PxBoxGeometry(10.0f, 10.0f, 10.0f), material));
            scene.addActor(rs2);

            timer1.Start();

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            var tf = rs2.getGlobalPose().p;
            var tf2= rd.getGlobalPose().p;
            label1.Text = tf.y.ToString();
            label2.Text = tf2.y.ToString();
            scene?.simulate(0.1f);
            scene?.fetchResults(true);
        }
    }
}